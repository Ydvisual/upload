// Copyright YD Visual, June 2024


#include "MazeGenerator.h"
#include "Engine/Engine.h"
#include "Materials/MaterialInterface.h"
#include "Math/UnrealMathUtility.h"
#include "Components/InstancedStaticMeshComponent.h" // Added manually
#include "Engine/StaticMesh.h"
#include "Containers/Queue.h"       // Include for TQueue
#include "Containers/Array.h"       // Include for TArray
#include "Algo/Reverse.h"           // Include for Algo::Reverse
#include "Templates/Function.h"     // Include for TFunction

// Sets default values
AMazeGenerator::AMazeGenerator()
{
    PrimaryActorTick.bCanEverTick = true;

    width = 32;
    height = 24;
    seed = 0;
    PathScale = 0.120f;

    USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComp"));
    SetRootComponent(SceneComponent);

    // ISM for the maze blocks
    MazeComp = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("MazeComp"));
    MazeComp->SetupAttachment(SceneComponent);

    // ISM for the pathway through maze
    PathComp = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("PathComp"));
    PathComp->SetupAttachment(SceneComponent);
    PathComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);

}


// Called when the game starts or when spawned
void AMazeGenerator::BeginPlay()
{
    Super::BeginPlay();

}

// Called every frame
void AMazeGenerator::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

}

void EnsureOddDimensions(int32& Width, int32& Height)
{
    if (Width % 2 == 0) Width++;
    if (Height % 2 == 0) Height++;
}

void AMazeGenerator::OnConstruction(const FTransform& Transform)
{
    // Ensure MazeComp and PathComp are valid
    if (!MazeComp || !PathComp) return;

    // Set the static meshes and materials for MazeComp and PathComp
    if (MeshForMaze)
    {
        MazeComp->SetStaticMesh(MeshForMaze);
    }
    if (MazeMaterial)
    {
        MazeComp->SetMaterial(0, MazeMaterial);
    }
    if (MeshForPath)
    {
        PathComp->SetStaticMesh(MeshForPath);
    }
    if (PathMaterial)
    {
        PathComp->SetMaterial(0, PathMaterial);
    }

    // Clear any existing instances
    MazeComp->ClearInstances();
    PathComp->ClearInstances();

    // Ensure width and height are odd numbers
    EnsureOddDimensions(width, height);

    // Seed the random number generator
    FRandomStream RandomStream(seed);

    // Get the size of the static mesh
    UStaticMesh* WallMesh = MazeComp->GetStaticMesh();
    if (!WallMesh) return;

    // Aspects of the mesh that makes the walls
    FVector WallMeshSize = WallMesh->GetBoundingBox().GetSize();
    FBox BoundingBox = WallMesh->GetBoundingBox();
    FVector PivotPoint = BoundingBox.GetCenter();

    //GEngine->AddOnScreenDebugMessage(-1, 4.0f, FColor::White, WallMeshSize.ToString());
    //GEngine->AddOnScreenDebugMessage(-1, 4.0f, FColor::Blue, PivotPoint.ToString());    

    // Initialize maze grid with walls
    TArray<TArray<bool>> MazeGrid;
    MazeGrid.SetNum(height);
    for (int32 Y = 0; Y < height; ++Y)
    {
        MazeGrid[Y].SetNum(width);
        for (int32 X = 0; X < width; ++X)
        {
            MazeGrid[Y][X] = false; // Initialize all cells as walls
        }
    }

    // Helper function to carve the maze (going old school for this one!)
    auto CarveMaze = [&MazeGrid, this, &RandomStream](int32 X, int32 Y, auto& CarveMazeRef) -> void
        {
            TArray<FIntPoint> Directions = { FIntPoint(0, -2), FIntPoint(0, 2), FIntPoint(-2, 0), FIntPoint(2, 0) };
            Directions.Sort([&RandomStream](const FIntPoint& A, const FIntPoint& B) { return RandomStream.FRand() > 0.5f; }); // Randomize direction order

            for (const FIntPoint& Direction : Directions)
            {
                int32 NX = X + Direction.X;
                int32 NY = Y + Direction.Y;

                if (NX > 0 && NX < width - 1 && NY > 0 && NY < height - 1 && !MazeGrid[NY][NX])
                {
                    MazeGrid[NY][NX] = true; // Carve path
                    MazeGrid[Y + Direction.Y / 2][X + Direction.X / 2] = true; // Carve intermediate cell
                    CarveMazeRef(NX, NY, CarveMazeRef); // Recur
                }
            }
        };

    // Initialize and carve the maze starting from (1, 1)
    MazeGrid[1][1] = true;
    CarveMaze(1, 1, CarveMaze);

    // Determine entrance and exit points
    TArray<FIntPoint> EdgePoints;

    // Collect all edge points
    for (int32 X = 0; X < width; ++X)
    {
        if (MazeGrid[1][X]) EdgePoints.Add(FIntPoint(X, 0)); // Top row
        if (MazeGrid[height - 2][X]) EdgePoints.Add(FIntPoint(X, height - 1)); // Bottom row
    }
    for (int32 Y = 0; Y < height; ++Y)
    {
        if (MazeGrid[Y][1]) EdgePoints.Add(FIntPoint(0, Y)); // Left column
        if (MazeGrid[Y][width - 2]) EdgePoints.Add(FIntPoint(width - 1, Y)); // Right column
    }

    // Randomly select entrance and exit
    FIntPoint Entrance = EdgePoints[RandomStream.RandRange(0, EdgePoints.Num() - 1)];
    FIntPoint Exit;
    do
    {
        Exit = EdgePoints[RandomStream.RandRange(0, EdgePoints.Num() - 1)];
    } while (Exit == Entrance);

    // Set entrance and exit in the maze grid
    MazeGrid[Entrance.Y][Entrance.X] = true;
    MazeGrid[Exit.Y][Exit.X] = true;

    // Breadth-First Search (BFS) to find the path from entrance to exit - going old-school again; this is the only way it works so far...
    TQueue<FIntPoint> Queue;
    TMap<FIntPoint, FIntPoint> CameFrom;
    Queue.Enqueue(Entrance);
    CameFrom.Add(Entrance, Entrance);

    while (!Queue.IsEmpty())
    {
        FIntPoint Current;
        Queue.Dequeue(Current);

        if (Current == Exit) break;

        TArray<FIntPoint> Neighbors = {
            FIntPoint(Current.X + 1, Current.Y),
            FIntPoint(Current.X - 1, Current.Y),
            FIntPoint(Current.X, Current.Y + 1),
            FIntPoint(Current.X, Current.Y - 1)
        };

        for (const FIntPoint& Neighbor : Neighbors)
        {
            if (MazeGrid.IsValidIndex(Neighbor.Y) && MazeGrid[Neighbor.Y].IsValidIndex(Neighbor.X) && MazeGrid[Neighbor.Y][Neighbor.X])
            {
                if (!CameFrom.Contains(Neighbor))
                {
                    Queue.Enqueue(Neighbor);
                    CameFrom.Add(Neighbor, Current);
                }
            }
        }
    }

    // Reconstruct the path from exit to entrance
    TArray<FIntPoint> Path;
    FIntPoint Current = Exit;
    while (Current != Entrance)
    {
        Path.Add(Current);
        Current = CameFrom[Current];
    }
    Path.Add(Entrance);
    Algo::Reverse(Path);

    // Calculate the offset to center the maze around the actor
    FVector MazeOffset = FVector(-width / 2.0f * WallMeshSize.X, -height / 2.0f * WallMeshSize.Y, 0.0f);

    // Add instances for walls - taking into account da pivot point of the da meshy
    for (int32 Y = 0; Y < height; ++Y)
    {
        for (int32 X = 0; X < width; ++X)
        {
            if (!MazeGrid[Y][X] && !(FIntPoint(X, Y) == Entrance || FIntPoint(X, Y) == Exit))
            {
                FVector Location = FVector(X * WallMeshSize.X, Y * WallMeshSize.Y, ((WallMeshSize.Z / 2.0f) - PivotPoint.Z)) + MazeOffset;
                FTransform InstanceTransform(Location);
                MazeComp->AddInstance(InstanceTransform);
            }
        }
    }

    // Add instances for the path using WallMeshSize, but set Z to 0
    // Sometimes path meshes are below floor(z=0 level - MUST FIX , WTF IS GOING ON)
    FVector PathScaleVector(PathScale, PathScale, PathScale); // Use the PathScale float to create a scale vector
    for (const FIntPoint& Point : Path)
    {
        FVector Location = FVector(Point.X * WallMeshSize.X, Point.Y * WallMeshSize.Y, 0.0f) + MazeOffset;
        FTransform InstanceTransform(Location);
        InstanceTransform.SetScale3D(PathScaleVector);
        PathComp->AddInstance(InstanceTransform);
    }
}
