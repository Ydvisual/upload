// Copyright YD Visual June 2024

#pragma once

#include "CoreMinimal.h"
#include "Components/InstancedStaticMeshComponent.h" // added manually
#include "Engine/StaticMesh.h" // added manually
#include "GameFramework/Actor.h"
#include "MazeGenerator.generated.h"

UCLASS()
class BLOCKMAZEGEN_API AMazeGenerator : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AMazeGenerator();

	virtual void OnConstruction(const FTransform& Transform) override; // Added manually

	UPROPERTY(BlueprintReadWrite, Category = "Maze Generator")
	class UInstancedStaticMeshComponent* MazeComp;

	UPROPERTY(BlueprintReadWrite, Category = "Maze Generator")
	class UInstancedStaticMeshComponent* PathComp;

	UPROPERTY(EditAnywhere, Category = "Maze Generator");
	int width;

	UPROPERTY(EditAnywhere, Category = "Maze Generator");
	int height;

	UPROPERTY(EditAnywhere, Category = "Maze Generator");
	int seed;

	UPROPERTY(EditAnywhere, Category = "Maze Generator");
	float PathScale;

	UPROPERTY(EditAnywhere, Category = "Maze Generator")
	class UStaticMesh* MeshForMaze;

	UPROPERTY(EditAnywhere, Category = "Maze Generator")
	class UMaterialInterface* MazeMaterial;

	UPROPERTY(EditAnywhere, Category = "Maze Generator")
	class UStaticMesh* MeshForPath;

	UPROPERTY(EditAnywhere, Category = "Maze Generator")
	class UMaterialInterface* PathMaterial;


protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
