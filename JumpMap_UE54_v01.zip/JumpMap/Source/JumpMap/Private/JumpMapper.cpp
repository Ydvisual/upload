// Copyright YD Visual September 2024


#include "JumpMapper.h"
#include "Engine/Engine.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/SceneComponent.h"


// Sets default values
AJumpMapper::AJumpMapper()
{
    // Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
    PrimaryActorTick.bCanEverTick = true;

    DefaultSceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("DefaultSceneRoot"));
    RootComponent = DefaultSceneRoot;
    BaseMesh = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("BaseMesh"));
    BaseMesh->SetupAttachment(RootComponent);
}


void AJumpMapper::OnConstruction(const FTransform& Transform)
{
    Super::OnConstruction(Transform);

    // Clear any existing instances
    if (BaseMesh)
    {
        BaseMesh->ClearInstances();
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("BaseMesh is null."));
        return;
    }

    // Ensure BaseMesh has a StaticMesh assigned
    if (!BaseMesh->GetStaticMesh())
    {
        UE_LOG(LogTemp, Warning, TEXT("BaseMesh does not have a StaticMesh assigned."));
        return;
    }

    // Measure the bounding box (x-width only) of BaseMesh
    float mesh_sz = 0.0f;
    {
        FBoxSphereBounds Bounds = BaseMesh->GetStaticMesh()->GetBounds();
        mesh_sz = Bounds.BoxExtent.X * 2.0f; // Multiply by 2 to get the full width
    }

    // Calculate walk_sz
    float walk_sz = mesh_sz * GapFactor;

    // Platform positions
    TArray<FVector> Positions;
    TSet<FVector> VisitedPositions;

    // Initialize random stream with the given seed
    FRandomStream RandomStream(Seed);

    // Directions to move: {(-X), (+X), (-Y), (+Y)}
    const TArray<FVector> Directions = {
        FVector(-walk_sz, 0.0f, 0.0f), // 0
        FVector(walk_sz, 0.0f, 0.0f),  // 1
        FVector(0.0f, -walk_sz, 0.0f), // 2
        FVector(0.0f, walk_sz, 0.0f)   // 3
    };

    // Start position is the actor's location
    FVector CurrentPosition = GetActorLocation();
    Positions.Add(CurrentPosition);
    VisitedPositions.Add(CurrentPosition);

    // Stack for backtracking
    TArray<FVector> PositionStack;
    PositionStack.Push(CurrentPosition);

    int32 StepsTaken = 0;

    // Keep track of the previous direction index
    int32 PreviousDirectionIndex = -1; // -1 indicates no previous direction

    while (StepsTaken < (StepCount-1) && PositionStack.Num() > 0)
    {
        CurrentPosition = PositionStack.Top();

        // List of available direction indices
        TArray<int32> AvailableDirections;

        // Check all directions for availability
        for (int32 i = 0; i < Directions.Num(); ++i)
        {
            FVector NextPosition = CurrentPosition + Directions[i];
            if (!VisitedPositions.Contains(NextPosition))
            {
                AvailableDirections.Add(i);
            }
        }

        if (AvailableDirections.Num() == 0)
        {
            // All neighboring positions have been visited; backtrack
            PositionStack.Pop();
            // Reset the previous direction since we're backtracking
            PreviousDirectionIndex = -1;
            continue;
        }

        int32 ChosenDirectionIndex = -1;

        if (PreviousDirectionIndex != -1 && AvailableDirections.Contains(PreviousDirectionIndex))
        {
            // Decide whether to continue in the same direction
            float RandomValue = RandomStream.FRand(); // Generates a float between 0.0 and 1.0
            if (RandomValue < DirectionBias)
            {
                // Continue in the same direction
                ChosenDirectionIndex = PreviousDirectionIndex;
            }
        }

        if (ChosenDirectionIndex == -1)
        {
            // Randomly select from available directions
            int32 RandomIndex = RandomStream.RandRange(0, AvailableDirections.Num() - 1);
            ChosenDirectionIndex = AvailableDirections[RandomIndex];
        }

        // Move to the next position
        FVector NextPosition = CurrentPosition + Directions[ChosenDirectionIndex];
        Positions.Add(NextPosition);
        VisitedPositions.Add(NextPosition);
        PositionStack.Push(NextPosition);
        StepsTaken++;

        // Update previous direction
        PreviousDirectionIndex = ChosenDirectionIndex;
    }

    float zval = 0.0f;
    float MicroScaleMin = 0.990f;
    float MicroScaleMax = 1.000f;

    if (bAntiOverlap == false) {
        MicroScaleMin = 1.0f;
        MicroScaleMax = 1.0f;
    }

    for (const FVector& Position : Positions)
    {
        FTransform InstanceTransform;

        // Adjust Z position dynamically for each instance
        FVector UpdatedPosition = Position;
        UpdatedPosition.Z = GetActorLocation().Z + zval;

        // Probability of going higher in Z
        if (RandomStream.FRand() <= HeightChangeFactor)
        {
            zval += HeightIncrement;
        }

        InstanceTransform.SetLocation(UpdatedPosition - GetActorLocation()); // Relative to the actor        

        // Generate a small random scale factor to prevent Z-fighting
        float MicroScaleX = RandomStream.FRandRange(MicroScaleMin, MicroScaleMax);
        float MicroScaleY = RandomStream.FRandRange(MicroScaleMin, MicroScaleMax);
        float MicroScaleZ = RandomStream.FRandRange(MicroScaleMin, MicroScaleMax);

        // Stop Z-Fighting!!!
        FVector AdjustedScale = InstanceScale * FVector(MicroScaleX, MicroScaleY, MicroScaleZ);
        InstanceTransform.SetScale3D(AdjustedScale);

        BaseMesh->AddInstance(InstanceTransform);
    }

}

void AJumpMapper::BeginPlay()
{
    Super::BeginPlay();

    GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Green, TEXT("AJumpMapper BeginPlay()"));

}
void AJumpMapper::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

}

