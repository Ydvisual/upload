// Copyright YD Visual September 2024


#include "JumpMapper.h"
#include "Engine/Engine.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/SceneComponent.h"


// Sets default values
AJumpMapper::AJumpMapper()
{
    // Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
    PrimaryActorTick.bCanEverTick = true;

    DefaultSceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("DefaultSceneRoot"));
    RootComponent = DefaultSceneRoot;
    BaseMesh = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("BaseMesh"));
    BaseMesh->SetupAttachment(RootComponent);
}


void AJumpMapper::OnConstruction(const FTransform& Transform)
{
    Super::OnConstruction(Transform);

    // Clear any existing instances
    if (BaseMesh)
    {
        BaseMesh->ClearInstances();
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("BaseMesh is null."));
        return;
    }

    // Ensure BaseMesh has a StaticMesh assigned
    if (!BaseMesh->GetStaticMesh())
    {
        UE_LOG(LogTemp, Warning, TEXT("BaseMesh does not have a StaticMesh assigned."));
        return;
    }

    // Perform self-avoiding random walk with backtracking
    TArray<FIntPoint> Path;
    TSet<FIntPoint> Visited;
    FRandomStream RandomStream(Seed);

    // Possible movement directions
    FIntPoint Deltas[4] = {
        FIntPoint(1, 0),
        FIntPoint(-1, 0),
        FIntPoint(0, 1),
        FIntPoint(0, -1)
    };

    // Initialize starting position
    Path.Add(FIntPoint(0, 0));
    Visited.Add(FIntPoint(0, 0));

    int32 PreviousDirectionIndex = -1; // No previous direction at the start

    bool bSuccess = false;

    while (Path.Num() > 0)
    {
        if (Path.Num() == StepCount)
        {
            bSuccess = true;
            break;
        }

        FIntPoint CurrentPos = Path.Last();
        TArray<int32> AvailableDirectionIndices;
        TArray<FIntPoint> AvailableNeighbors;

        // Find unvisited neighboring positions
        for (int32 i = 0; i < 4; ++i)
        {
            FIntPoint Neighbor = CurrentPos + Deltas[i];
            if (!Visited.Contains(Neighbor))
            {
                AvailableDirectionIndices.Add(i);
                AvailableNeighbors.Add(Neighbor);
            }
        }

        if (AvailableNeighbors.Num() > 0)
        {
            int32 ChosenDirectionIndex = -1;

            if (StraightnessFactor > 0.0f && PreviousDirectionIndex != -1)
            {
                // Assign weights based on ContinuityProbability
                TArray<float> Weights;
                float TotalWeight = 0.0f;

                for (int32 i = 0; i < AvailableDirectionIndices.Num(); ++i)
                {
                    int32 DirectionIndex = AvailableDirectionIndices[i];
                    if (DirectionIndex == PreviousDirectionIndex)
                    {
                        // Assign continuity probability to the previous direction
                        Weights.Add(StraightnessFactor);
                    }
                    else
                    {
                        // Distribute the remaining probability among other directions
                        float RemainingProbability = 1.0f - StraightnessFactor;
                        float Weight = RemainingProbability / (AvailableNeighbors.Num() - 1);
                        Weights.Add(Weight);
                    }
                    TotalWeight += Weights.Last();
                }

                // Normalize weights in case of floating-point errors
                for (int32 i = 0; i < Weights.Num(); ++i)
                {
                    Weights[i] /= TotalWeight;
                }

                // Select next direction based on weighted probabilities
                float RandomValue = RandomStream.GetFraction();
                float AccumulatedWeight = 0.0f;
                for (int32 i = 0; i < Weights.Num(); ++i)
                {
                    AccumulatedWeight += Weights[i];
                    if (RandomValue <= AccumulatedWeight)
                    {
                        ChosenDirectionIndex = AvailableDirectionIndices[i];
                        break;
                    }
                }

                // Fallback in case of floating-point inaccuracies
                if (ChosenDirectionIndex == -1)
                {
                    ChosenDirectionIndex = AvailableDirectionIndices.Last();
                }
            }
            else
            {
                // No bias, choose a random direction
                int32 Index = RandomStream.RandRange(0, AvailableNeighbors.Num() - 1);
                ChosenDirectionIndex = AvailableDirectionIndices[Index];
            }

            // Move to the chosen neighbor
            FIntPoint NextPos = CurrentPos + Deltas[ChosenDirectionIndex];
            Path.Add(NextPos);
            Visited.Add(NextPos);
            PreviousDirectionIndex = ChosenDirectionIndex;
        }
        else
        {
            // Backtrack if no unvisited neighbors (note this fails sometimes - fix!!!)
            Path.RemoveAt(Path.Num() - 1);
            // Do not remove from Visited to prevent revisiting
            if (Path.Num() > 0)
            {
                // Update PreviousDirectionIndex based on the new last position
                FIntPoint NewCurrentPos = Path.Last();

                // Determine the direction from the new current position to the previous one
                FIntPoint Direction = CurrentPos - NewCurrentPos;
                for (int32 i = 0; i < 4; ++i)
                {
                    if (Deltas[i] == Direction)
                    {
                        PreviousDirectionIndex = i;
                        break;
                    }
                }
            }
            else
            {
                PreviousDirectionIndex = -1;
            }
        }
    }

    if (!bSuccess)
    {
        UE_LOG(LogTemp, Warning, TEXT("Could not complete the walk with the given StepCount."));
        return;
    }

    // Measure the bounding box (x width only) of BaseMesh
    UStaticMesh* StaticMesh = BaseMesh->GetStaticMesh();
    if (!StaticMesh)
    {
        UE_LOG(LogTemp, Warning, TEXT("StaticMesh is null."));
        return;
    }

    // Get the bounding box size (x-axis)
    FBoxSphereBounds Bounds = StaticMesh->GetBounds();
    float mesh_sz = Bounds.BoxExtent.X * 2.0f; // BoxExtent is half the size
    float walk_sz = mesh_sz * GapFactor;

    // Create instances based on the walk data
    float CurrentHeight = 0.0f; // Track the current height
    FVector AdjustedScale = InstanceScale; // Use adjusted scale if needed


    for (int32 i = 0; i < Path.Num(); ++i)
    {
        FIntPoint GridPos = Path[i];
        FVector Location = FVector(
            GridPos.X * walk_sz,
            GridPos.Y * walk_sz,
            CurrentHeight // Set the current height
        );

        FTransform InstanceTransform;
        InstanceTransform.SetLocation(Location);

        // Apply anti-flicker behavior if enabled
        if (bAntiFlicker)
        {
            FVector AntiFlickerAdjustment = FVector(RandomStream.FRandRange(0.992f, 1.008f));
            AdjustedScale = InstanceScale * AntiFlickerAdjustment;
        }
        else
        {
            AdjustedScale = InstanceScale; // Use the normal scale if anti-flicker is disabled
        }
        InstanceTransform.SetScale3D(AdjustedScale);
        BaseMesh->AddInstance(InstanceTransform);
        if (RandomStream.FRand() <= HeightShiftFactor)
        {
            CurrentHeight += HeightIncrement;
        }
    }
}

void AJumpMapper::BeginPlay()
{
    Super::BeginPlay();

    GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Green, TEXT("AJumpMapper BeginPlay()"));

}
void AJumpMapper::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

}

