// Copyright YD Visual August 2024

#include "QR_CodeMaker.h"
#include "Engine/Texture2D.h"
#include "Engine/Texture.h"
#include "RenderUtils.h" // For EPixelFormat
#include "TextureResource.h" // For FTexture2DMipMap
#include "TimerManager.h" // For GetWorld()->GetTimerManager().SetTimer() calls
#include "Engine/Engine.h"


// Sets default values
AQR_CodeMaker::AQR_CodeMaker()
{
    // Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
    PrimaryActorTick.bCanEverTick = true;

    USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComp"));
    SetRootComponent(SceneComponent);

    // ISM for the blocks
    CellComp = CreateDefaultSubobject<UInstancedStaticMeshComponent>(TEXT("CellComp"));
    CellComp->SetupAttachment(SceneComponent);

    CellRotation = FVector(0.0f);
    CellScale = 1.0f;

    UE_LOG(LogTemp, Warning, TEXT("[QRCM] AQR_CodeMaker() - Class constructor"));
}

// Called when the game starts or when spawned
void AQR_CodeMaker::BeginPlay()
{
    Super::BeginPlay();
    UE_LOG(LogTemp, Warning, TEXT("[QRCM] AQR_CodeMaker() - BeginPlay"));
}

// Called every frame
void AQR_CodeMaker::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

int AQR_CodeMaker::CreateCells(FString msg)
{
    UE_LOG(LogTemp, Warning, TEXT("[QRCM] >>>> CreateCells: %s"), *msg);

    CellComp->ClearInstances();
           
    if (!InputTexture || !InputTexture->GetPlatformData())
    {
        UE_LOG(LogTemp, Warning, TEXT("[QRCM] Failed to cast to UTexture2D or GetPlatformData() returned null."));
        return -1;
    }

    // Lock the texture to read the pixel data
    int mip_count = InputTexture->GetPlatformData()->Mips.Num();
    UE_LOG(LogTemp, Warning, TEXT("[QRCM] mip_count: %d"), mip_count);
    if (mip_count <= 0) {
        UE_LOG(LogTemp, Warning, TEXT("[QRCM] Giving up since mip_count is <= 0."));
        return -1;
    }
    FTexture2DMipMap& MipMap = InputTexture->GetPlatformData()->Mips[0];
    void* Data = MipMap.BulkData.Lock(LOCK_READ_ONLY);

    if (!Data)
    {
        UE_LOG(LogTemp, Warning, TEXT("[QRCM] Failed to lock the texture data."));
        return -1;
    }

    // Get the width, height, and pixel format of the texture
    int32 Width = InputTexture->GetSizeX();
    int32 Height = InputTexture->GetSizeY();
    EPixelFormat PixelFormat = InputTexture->GetPixelFormat(0);

    // Ensure the pixel format is supported
    if (PixelFormat != PF_B8G8R8A8)
    {
        UE_LOG(LogTemp, Warning, TEXT("[QRCM] Unsupported pixel format. (Expecting: PF_B8G8R8A8)"));
        MipMap.BulkData.Unlock();
        return -1;
    }

    // Read the pixel data
    TArray<FColor> Pixels;
    Pixels.SetNumUninitialized(Width * Height);
    FMemory::Memcpy(Pixels.GetData(), Data, Width * Height * sizeof(FColor));

    // Unlock the texture
    MipMap.BulkData.Unlock();

    // Find the middle row, col
    int32 MiddleRow = Height / 2;
    int32 MiddleCol = Width / 2;

    // Data is now in Pixels[] - array of FColor
    FIntPoint FirstDarkPixel(-1, -1);
    FIntPoint FirstLightPixel(-1, -1);

    // Define the threshold for darkness
    const uint8 DarkThreshold = 80;

    // Find top left of QR code by pixel
    UE_LOG(LogTemp, Warning, TEXT("[QRCM] Searching for dark pixel(MiddleCol,MiddleRow) px: (%d, %d)"), MiddleCol, MiddleRow);
    for (int32 Y = 0; Y <= MiddleRow; Y++)
    {
        for (int32 X = 0; X <= MiddleCol; X++)
        {
            int pixelIndex = Y * Width + X;
            if (pixelIndex >= 0 && pixelIndex < Pixels.Num()) {
                FColor PixelColor = Pixels[pixelIndex];
                if (PixelColor.R < DarkThreshold && PixelColor.G < DarkThreshold && PixelColor.B < DarkThreshold)
                {
                    FirstDarkPixel = FIntPoint(X, Y);
                    break;
                }
            }
        }
        if (FirstDarkPixel != FIntPoint(-1, -1))
        {
            break;
        }
    }
    UE_LOG(LogTemp, Warning, TEXT("[QRCM] First dark pixel found at: (%d, %d)"), FirstDarkPixel.X, FirstDarkPixel.Y);

    // Find the bottom of the first pattern marker
    if (FirstDarkPixel != FIntPoint(-1, -1))
    {
        // Find the first light pixel in the same column        
        const uint8 LightThreshold = 120;

        for (int32 Y = FirstDarkPixel.Y; Y < Height; Y++)
        {
            int pixelIndex = Y * Width + FirstDarkPixel.X;
            if (pixelIndex >= 0 && pixelIndex < Pixels.Num()) {
                FColor PixelColor = Pixels[pixelIndex];
                if (PixelColor.R > LightThreshold && PixelColor.G > LightThreshold && PixelColor.B > LightThreshold)
                {
                    FirstLightPixel = FIntPoint(FirstDarkPixel.X, Y);
                    break;
                }
            }
        }

        // Log the location of the first light pixel
        if (FirstLightPixel != FIntPoint(-1, -1))
        {
            UE_LOG(LogTemp, Warning, TEXT("[QRCM] First light pixel found at: (%d, %d)"), FirstLightPixel.X, FirstLightPixel.Y);
        }
        else
        {
            UE_LOG(LogTemp, Warning, TEXT("[QRCM] No light pixel found in the scanned column."));
            return -1;
        }
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("[QRCM] No dark pixel found in the scanned area."));
        return -1;
    }

    // Pixels per cell calc
    int cell_pixels = 0;
    int cells_in_pattern = 7;

    cell_pixels = (FirstLightPixel.Y - FirstDarkPixel.Y) / cells_in_pattern;
    UE_LOG(LogTemp, Warning, TEXT("[QRCM] cell_pixels: %d"), cell_pixels);

    // Prepare mesh for QR code display
    FVector MeshSize = FVector(0.0f);
    if (MeshForCell)
    {
        FBox BoundingBox = MeshForCell->GetBoundingBox();
        MeshSize = BoundingBox.GetSize();

        // Now you can use BoundingBoxSize.X, BoundingBoxSize.Y, BoundingBoxSize.Z
        UE_LOG(LogTemp, Warning, TEXT("[QRCM] Bounding Box Size: %s"), *MeshSize.ToString());
        CellComp->SetStaticMesh(MeshForCell);        
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("[QRCM] MeshForCell is not set!"));
        return -1;
    }

    // Set Material for cell
    if (MaterialForCell) {
        CellComp->SetMaterial(0, MaterialForCell);
    }

    // Sample the image at cell sized locations(idx/idy are in pixel space)
    int start_x = FirstDarkPixel.X + 1;
    int start_y = FirstDarkPixel.Y + 1;

    int cell_x_idx = 0;
    int cell_y_idx = 0;
    int count = 0;
    TArray<FIntPoint> CellLocations;

    UE_LOG(LogTemp, Warning, TEXT("[QRCM] Sample TOOL prep: Start(%d,%d) at steps of %d"), start_x, start_y, cell_pixels);

    for (int idy = start_y; idy <= (Height - cell_pixels); idy += cell_pixels) {
        for (int idx = start_x; idx <= (Width - cell_pixels); idx += cell_pixels) {
            int pixelIndex = (idy * Width) + idx;

            // Check if pixelIndex is within the bounds of the Pixels array
            if (pixelIndex >= 0 && pixelIndex < Pixels.Num()) {
                FColor PixelColor = Pixels[pixelIndex];

                if (PixelColor.R < 80 && PixelColor.G < 80 && PixelColor.B < 80) {
                    count++;
                    CellLocations.Add(FIntPoint(cell_x_idx, cell_y_idx));
                }
            }
            else {
                UE_LOG(LogTemp, Warning, TEXT("[QRCM] Pixel index out of bounds: %d"), pixelIndex);
            }
            cell_x_idx++;
        }
        cell_x_idx = 0;
        cell_y_idx++;
    }

    // Center the QR Code
    if (CellLocations.Num() > 0)
    {
        int32 MaxX = 0;
        int32 MaxY = 0;
        for (const FIntPoint& CellLocation : CellLocations)
        {
            if (CellLocation.X > MaxX)
            {
                MaxX = CellLocation.X;
            }
            if (CellLocation.Y > MaxY)
            {
                MaxY = CellLocation.Y;
            }
        }
        int32 MiddleX = MaxX / 2;
        int32 MiddleY = MaxY / 2;
        for (FIntPoint& CellLocation : CellLocations)
        {
            CellLocation.X -= MiddleX;
            CellLocation.Y -= MiddleY;
        }
    }

    // Add instances where Cells are
    for (const FIntPoint& CellLocation : CellLocations)
    {
        //UE_LOG(LogTemp, Warning, TEXT("Cell Location: (%d, %d)"), CellLocation.X, CellLocation.Y);

        FTransform InstanceTransform;
        float px = CellLocation.X * MeshSize.X;
        float py = 0.0f;
        float pz = -1.0f * (CellLocation.Y * MeshSize.Y);
        InstanceTransform.SetLocation(FVector(px, py, pz));
        
        // Rotation
        //FRotator RotationForCell = TransformForCell.GetRotation().Rotator();
        //InstanceTransform.SetRotation(RotationForCell.Quaternion());

        FRotator Rotation = FRotator::MakeFromEuler(CellRotation);
        InstanceTransform.SetRotation(Rotation.Quaternion());


        // scale
        //InstanceTransform.SetScale3D(TransformForCell.GetScale3D());
        InstanceTransform.SetScale3D(FVector(CellScale));
        
        CellComp->AddInstance(InstanceTransform);

    }

    // FTransform TransformForCell;
    UE_LOG(LogTemp, Warning, TEXT("[QRCM] AddInstances: %d"), count);

    return count;
}

void AQR_CodeMaker::TextureStatus() {

    UE_LOG(LogTemp, Warning, TEXT("[QRCM]-TEXTURE STATUS: %d x %d"), InputTexture->GetSizeX(), InputTexture->GetSizeY());
    EPixelFormat PixelFormat = InputTexture->GetPixelFormat();
    UE_LOG(LogTemp, Warning, TEXT("[QRCM]-TEXTURE STATUS: Pixel Format: %s"), *UEnum::GetValueAsString(PixelFormat));

    // Ready if size > 32 and pixel format OK
    int32 Width = InputTexture->GetSizeX();

    if ((Width > 32) && (PixelFormat == PF_B8G8R8A8)) {
        CreateCells(FString("From Texture Status"));
    }
    else {
        // Call again 
        GetWorld()->GetTimerManager().SetTimer(TextureCheckTimerHandle, this, &AQR_CodeMaker::TextureStatus, 0.25f, false);
    }    
}

void AQR_CodeMaker::CheckTextureReady()
{
    // Make sure texture selected - if not call this function again on a timer.
    if (!InputTexture || !InputTexture->IsFullyStreamedIn())
    {
        UE_LOG(LogTemp, Warning, TEXT("[QRCM]-CTR: Texture is not ready, retrying..."));
        GetWorld()->GetTimerManager().SetTimer(TextureCheckTimerHandle, this, &AQR_CodeMaker::CheckTextureReady, 0.25f, false);
        return;
    }

    // Make sure the texture is not the temporary loaded texture, if not call again
    if (InputTexture->GetSizeX() <= 32 || InputTexture->GetSizeY() <= 32)
    {
        UE_LOG(LogTemp, Warning, TEXT("[QRCM]-CTR Texture is still low resolution, retrying..."));
        GetWorld()->GetTimerManager().SetTimer(TextureCheckTimerHandle, this, &AQR_CodeMaker::CheckTextureReady, 0.25f, false);
        return;
    }
    
    // Texture now fully loaded
    UE_LOG(LogTemp, Warning, TEXT("[QRCM]-CTR InputTexture now: %d x %d"), InputTexture->GetSizeX(), InputTexture->GetSizeY());    
    EPixelFormat PixelFormat = InputTexture->GetPixelFormat();
    UE_LOG(LogTemp, Warning, TEXT("InputTexture Pixel Format: %s"), *UEnum::GetValueAsString(PixelFormat));
    
    // Change to VectorDisplacementmap - then wait for update with TextureStatus()
    if (PixelFormat != PF_B8G8R8A8) {
        InputTexture->CompressionSettings = TextureCompressionSettings::TC_VectorDisplacementmap;
        InputTexture->SRGB = false;
        InputTexture->UpdateResource(); // Will cause 32x32 temp image reload
        UE_LOG(LogTemp, Warning, TEXT("[QRCM]-CTR - Format was not PF_B8G8R8A8, updating to: VectorDisplacementmap, called UpdateResource()."));
    }    

    TextureStatus();
}



void AQR_CodeMaker::OnConstruction(const FTransform& Transform)
{
    Super::OnConstruction(Transform);

    UE_LOG(LogTemp, Warning, TEXT("[QRCM] OnConstruction()"));

    // Wait for texture to be fully loaded in and in correct pixel format.
    CheckTextureReady();

}
