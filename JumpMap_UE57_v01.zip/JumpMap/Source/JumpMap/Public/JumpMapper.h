// Copyright YD Visual September 2024

#pragma once

#include "CoreMinimal.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "GameFramework/Actor.h"
#include "JumpMapper.generated.h"

UCLASS()
class JUMPMAP_API AJumpMapper : public AActor
{
	GENERATED_BODY()

public:	
	AJumpMapper();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	// Root
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	USceneComponent* DefaultSceneRoot;

	// ISM: Base Mesh
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	UInstancedStaticMeshComponent* BaseMesh;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	
	// Called when the actor is constructed in the editor or during gameplay
	virtual void OnConstruction(const FTransform& Transform) override;	

	// User controlled properties
	UPROPERTY(EditAnywhere, Category = "Platform Generator", meta = (DisplayPriority = 1, ToolTip = "Spacing between platforms."))
	float GapFactor = 1.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Platform Generator", meta = (DisplayPriority = 2,
		ClampMin = "0.0",
		ClampMax = "1.0",
		ToolTip = "Value between 0 and 1. Values closer to 1.0 produce more straight paths."))
	float StraightnessFactor = 0.70f;

	UPROPERTY(EditAnywhere, Category = "Platform Generator", meta = (DisplayPriority = 3, ToolTip = "Amount of height increase when going up a step."))
	float HeightIncrement = 40.0f;

	UPROPERTY(EditAnywhere, Category = "Platform Generator", meta = (DisplayPriority = 4, 
		ClampMin = "0.0",
		ClampMax = "1.0",
		ToolTip = "Value between 0 and 1. How often to go up in height.  Value of 1.0 means go up every step."))
	float HeightShiftFactor = 0.25f;

	// Scale
	UPROPERTY(EditAnywhere, Category = "Platform Generator", meta = (DisplayPriority = 5, ToolTip = "Scale the size of the mesh."))
	FVector InstanceScale = FVector(1.0f, 1.0f, 1.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Platform Generator", meta = (DisplayPriority = 6, 
	ToolTip = "Enable or disable anti-flicker behavior (flickering textures)"))
	bool bAntiFlicker = false;

	// Seed for random
	UPROPERTY(EditAnywhere, Category = "Platform Generator", meta = (DisplayPriority = 7, ToolTip = "Seed for random path generator."))
	int32 Seed = 12345;

	// Steps (number of platforms to make)
	UPROPERTY(EditAnywhere, Category = "Platform Generator", meta = (DisplayPriority = 8, ToolTip = "Number of platforms to create."))
	int32 StepCount = 50;

};
