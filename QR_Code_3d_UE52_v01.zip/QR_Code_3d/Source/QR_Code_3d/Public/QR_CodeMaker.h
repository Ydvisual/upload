// Copyright YD Visual August 2024

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/InstancedStaticMeshComponent.h" // For ISM component
#include "Engine/StaticMesh.h" // UStaticMesh = MeshForCell
#include "Engine/Texture.h" // For UTexture
#include "Materials/MaterialInterface.h"
#include "QR_CodeMaker.generated.h"


UCLASS()
class QR_CODE_3D_API AQR_CodeMaker : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AQR_CodeMaker();

	virtual void OnConstruction(const FTransform& Transform) override;
	int CreateCells(FString msg);

	// Cell ISM for QR Code
	UPROPERTY(BlueprintReadWrite, Category = "QR Code Maker")
	class UInstancedStaticMeshComponent* CellComp;

	// Input texture
	UPROPERTY(EditAnywhere, Category = "QR Code Maker")
	UTexture2D* InputTexture;

	UPROPERTY(EditAnywhere, Category = "QR Code Maker")
	class UStaticMesh* MeshForCell;

	UPROPERTY(EditAnywhere, Category = "QR Code Maker")
	class UMaterialInterface* MaterialForCell;

	UPROPERTY(EditAnywhere, Category = "QR Code Maker")
	FVector CellRotation;

	UPROPERTY(EditAnywhere, Category = "QR Code Maker") 
	float CellScale;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	void TextureStatus();
	void CheckTextureReady();
	FTimerHandle TextureCheckTimerHandle;

};
