// Copyright YD Visual, June 2024

#include "QR_Code_3d.h"

#define LOCTEXT_NAMESPACE "FQR_Code_3dModule"

void FQR_Code_3dModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
}

void FQR_Code_3dModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FQR_Code_3dModule, QR_Code_3d)